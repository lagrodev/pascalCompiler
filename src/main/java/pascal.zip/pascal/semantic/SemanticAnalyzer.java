package pascal.semantic;

public class SemanticAnalyzer {
}
